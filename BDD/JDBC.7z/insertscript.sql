use jdbcexample;

INSERT INTO students VALUES
(1, 'Person', 'One', '1995-10-06', 'Brasov'), 
(2, 'Person', 'Two', '1995-09-13', 'Bucuresti'),
(3, 'Person', 'Three', '1999-03-01', 'Cluj'), 
(4, 'Person', 'Four', '1998-03-17', 'Bucuresti'),
(5, 'Person', 'Five', '1997-03-22', 'Brasov'), 
(6, 'Person', 'Six', '1995-04-07', 'Brasov');